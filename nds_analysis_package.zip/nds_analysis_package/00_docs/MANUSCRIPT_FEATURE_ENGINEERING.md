# Manuscript Feature Engineering

This document describes only the feature engineering used by the current
manuscript package.

## Target definition

The manuscript analyzes target recognition at the first test, operationalized
as the target image's second presentation:

- `B1`: target first presentation.
- `B2`: target second presentation / first recognition test.
- Outcome: correctness at `B2`.

The analysis table contains one row per eligible `B1 -> B2` target transition.

## Neighbor anchor

A neighbor is a presentation event `A_m`, not an image selected by its first
overall encoding position. In the current package:

- The neighbor anchor must be within 256 raw trial-order steps of `B1`.
- The neighbor anchor must occur in the same session as `B1`.
- Distance is `abs(GLOBAL_ORDER(A_m) - GLOBAL_ORDER(B1))`.

## Neighbor follow-up retrievals

Each eligible neighbor anchor can contribute through up to two later
presentations:

- `A_(m+1)`
- `A_(m+2)`, if present

Each follow-up retrieval event is classified independently and pooled into the same predictor family. There is no any-success aggregation.

## Actual window

The current manuscript model uses actual neighbor retrievals:

```text
B1 order < A follow-up order < B2 order
```

## Accuracy family

Neighbor follow-up retrieval correctness defines:

- `acc`: follow-up retrieval was correct.
- `inc`: follow-up retrieval was incorrect or missing.

## Same/across relation

Same/across is defined at the retrieval-event level, not at initial encoding:

- `same`: neighbor follow-up retrieval and target `B2` occurred in the same session.
- `across`: neighbor follow-up retrieval and target `B2` occurred in different sessions.

## Four predictor cells

For each target row, actual neighbor retrievals are pooled into four cells:

- `actual_acc_same`
- `actual_acc_across`
- `actual_inc_same`
- `actual_inc_across`

## Measures

Closest-neighbor measure:

```text
closeness = 1 / nearest eligible distance
```

Weighted-decay measures:

```text
inverse_d       = sum(1 / d)
inverse_sqrt_d  = sum(1 / sqrt(d))
exp_h2          = sum(2 ** (-(d - 1) / 2))
exp_h8          = sum(2 ** (-(d - 1) / 8))
exp_h32         = sum(2 ** (-(d - 1) / 32))
exp_h128        = sum(2 ** (-(d - 1) / 128))
```

The manuscript uses `exp_h32` as the representative accumulated weighted-sum
model in the main figure.

