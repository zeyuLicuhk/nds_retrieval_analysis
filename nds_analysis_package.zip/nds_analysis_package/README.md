# NSD Manuscript Analysis Package

This package contains the analysis code, analysis-ready data, model outputs,
and figure-generation scripts for the current manuscript.

## Scope

Included:

- First-Test target-recognition analyses only.
- Event-anchor Followup12 neighbor definition.
- Same-session eligible neighbor anchors.
- Maximum event-anchor distance = 256 trials.
- Non-interaction models with log-lag control.
- Participant random intercepts.
- Closest-neighbor and accumulated weighted-history predictors.
- Manuscript figures: beta bar plot, zero-neighbor probability-change
  line chart, and optional method schematic.

## Main Model

For each neighborhood measure, the manuscript model is fit in R using
`lme4::glmer`:

```r
target_correct ~
  z(actual_acc_same) +
  z(actual_acc_across) +
  z(actual_inc_same) +
  z(actual_inc_across) +
  log_lag +
  (1 | subject)
```

`target_correct` is recognition accuracy at the target image's second
presentation. `log_lag` is the log-transformed lag between the target image's
first and second presentations. `(1 | subject)` models participant-specific
baseline recognition differences as random intercepts.

The four retrieval-history predictors are z-scored separately within each
neighborhood measure before model fitting. Reported coefficients are
standardized log-odds coefficients. Standard errors are frequentist Wald
standard errors from `lme4::glmer`.

Benjamini-Hochberg FDR correction is applied across the 28 primary
retrieval-history coefficients: seven neighborhood measures x four
retrieval-history cells.

## Directory Structure

```text
00_docs/
  Manuscript feature-engineering notes.

01_data/raw_data/
  Raw NSD behavioral response TSV files.

01_data/analysis_ready/
  Analysis-ready First-Test table:
  table_main_trialOrder_eventAnchor_sameSession_md256.csv

02_scripts/
  event_anchor_core.py
  build_main_table_only.py
  run_firsttest_lagonly_glmer_models.R
  plot_firsttest_betas.py
  plot_zero3_probability_change_line_chart_glmer.py

03_results_glmer/
  First-Test GLMM result CSV files.

04_figures_glmer/
  Manuscript figure outputs and Figure 2 prediction data.

05_reproducibility/
  Python/R requirements and SHA256 manifest.
```

## Reproduction

Run all commands from this package root.

### 1. Build the First-Test analysis table

```bash
python 02_scripts/build_main_table_only.py
```

Expected output:

```text
01_data/analysis_ready/table_main_trialOrder_eventAnchor_sameSession_md256.csv
```

The expected table shape is `(72402, 63)`.

### 2. Fit the manuscript GLMMs

```bash
Rscript 02_scripts/run_firsttest_lagonly_glmer_models.R
```

If `Rscript` is not on PATH, use the full path. For example, on the verified
local machine:

```powershell
& "F:\R-4.5.1\bin\x64\Rscript.exe" "02_scripts\run_firsttest_lagonly_glmer_models.R"
```

### 3. Generate manuscript figures

```bash
python 02_scripts/plot_firsttest_betas.py

python 02_scripts/plot_zero3_probability_change_line_chart_glmer.py --weighted-measure exp_h32 --closest-scale log

```

## Key Outputs

```text
03_results_glmer/firsttest_lagonly_glmer_all_measures.csv
03_results_glmer/firsttest_lagonly_glmer_closest.csv
03_results_glmer/firsttest_lagonly_glmer_weighted_decay_all.csv
03_results_glmer/firsttest_lagonly_glmer_manuscript_main_closeness_exp_h32.csv
03_results_glmer/firsttest_lagonly_glmer_fixed_terms.csv
03_results_glmer/firsttest_lagonly_glmer_diagnostics.csv
03_results_glmer/firsttest_lagonly_glmer_vcov_*.csv

04_figures_glmer/fig1_firsttest_closest_exp_h32_betas.png
04_figures_glmer/fig1_firsttest_closest_exp_h32_betas.svg
04_figures_glmer/fig2_zero3_probability_change_h32_glmer.png
04_figures_glmer/fig2_zero3_probability_change_h32_glmer.svg
04_figures_glmer/fig2_zero3_probability_change_h32_glmer.csv
```

## Figure 2 Prediction Curves

Figure 2 is generated from the fitted GLMMs without fitting additional models.

For closest-neighbor curves, predicted probability changes are computed as a
function of nearest-neighbor distance and expressed relative to a no-neighbor
reference case.

For accumulated weighted-history curves, predicted probability changes are
computed as each retrieval-history predictor increases from 0 to 3 standard
deviations above the no-neighbor reference.

Confidence intervals are pointwise 95% intervals computed using the delta
method from the fixed-effect covariance matrix of the fitted GLMM. Participant
random intercepts are set to zero for population-level predictions.

## Software

Python is used for table construction and figure generation. R is used for the
manuscript-facing GLMMs.

Required R package:

- `lme4`

Required Python packages:

- `pandas`
- `numpy`
- `matplotlib`

## Verified Run

The package was verified locally with:

- Python: `C:\Users\lenovo\anaconda3\python.exe`
- Rscript: `F:\R-4.5.1\bin\x64\Rscript.exe`
- R package: `lme4`

The raw-to-main-table build completed successfully and produced
`table_main_trialOrder_eventAnchor_sameSession_md256.csv`, shape `(72402, 63)`.

The GLMM pipeline completed successfully for all seven neighborhood measures.
All models converged with optimizer convergence code 0 and no singular fits.
