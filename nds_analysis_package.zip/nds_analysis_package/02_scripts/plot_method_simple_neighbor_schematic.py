from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle


ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT / "04_figures"
OUT_DIR.mkdir(exist_ok=True)


GREEN = "#2f7d5b"
BLUE_GRAY = "#4b5563"
BROWN = "#8a6334"
RED = "#c44e52"
GOLD = "#e0a11b"
LIGHT_GREEN = "#e8f2ec"
LIGHT_RED = "#f7ecec"
LIGHT_GRAY = "#f3f4f6"
MID_GRAY = "#6b7280"


def box(ax, x, y, w, h, text, fc="white", ec="#333333", lw=1.2, fs=10, weight="normal"):
    ax.add_patch(Rectangle((x, y), w, h, facecolor=fc, edgecolor=ec, linewidth=lw))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, weight=weight, linespacing=1.08)


def arrow(ax, x1, y1, x2, y2, color="#333333", lw=1.3, ms=13):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=ms, linewidth=lw, color=color))


def label(ax, x, y, text, color="#222222", fs=9.5, weight="normal", ha="center"):
    ax.text(x, y, text, ha=ha, va="center", fontsize=fs, color=color, weight=weight, linespacing=1.08)


def draw_schematic():
    plt.rcParams.update({"font.family": "Arial", "font.size": 10})
    fig, ax = plt.subplots(figsize=(11.8, 6.2), dpi=220)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 7)
    ax.axis("off")

    label(ax, 6, 6.62, "Method schematic: temporal neighbor classification", fs=15, weight="bold")

    # Session bands.
    ax.add_patch(Rectangle((0.75, 3.95), 4.1, 1.95, facecolor=LIGHT_GRAY, edgecolor="none"))
    ax.add_patch(Rectangle((5.05, 3.95), 4.1, 1.95, facecolor="#fafafa", edgecolor="none"))
    ax.add_patch(Rectangle((9.35, 3.95), 1.9, 1.95, facecolor=LIGHT_GRAY, edgecolor="none"))
    label(ax, 2.8, 5.72, "Session of target anchor", fs=9.3, weight="bold")
    label(ax, 7.1, 5.72, "Session of target test", fs=9.3, weight="bold")
    label(ax, 10.3, 5.72, "Later", fs=9.3, weight="bold")

    # Target timeline.
    label(ax, 0.5, 5.18, "Target B", color=BLUE_GRAY, fs=10, weight="bold", ha="left")
    box(ax, 2.0, 4.95, 0.95, 0.48, "B1", ec=BLUE_GRAY, fs=11, weight="bold")
    box(ax, 7.75, 4.95, 0.95, 0.48, "B2", ec=BLUE_GRAY, fs=11, weight="bold")
    arrow(ax, 3.05, 5.19, 7.63, 5.19, color=BLUE_GRAY)
    label(ax, 5.35, 5.43, "target interval", color=BLUE_GRAY, fs=9.2)

    # Neighbor timeline.
    label(ax, 0.5, 4.42, "Neighbor A", color=BROWN, fs=10, weight="bold", ha="left")
    box(ax, 1.45, 4.18, 1.15, 0.48, "A_m", fc="#fff8ed", ec=BROWN, fs=10.5, weight="bold")
    box(ax, 5.45, 4.18, 1.35, 0.48, "A_(m+1)", fc=LIGHT_GREEN, ec=GREEN, fs=9.7, weight="bold")
    box(ax, 9.75, 4.18, 1.35, 0.48, "A_(m+2)", fc="#f7f7f8", ec=MID_GRAY, fs=9.7, weight="bold")
    arrow(ax, 2.72, 4.42, 5.30, 4.42, color=BROWN)
    arrow(ax, 6.95, 4.42, 9.58, 4.42, color=BROWN)

    # Distance and classification annotations.
    label(ax, 2.2, 3.78, "near B1\n(d <= 256)", fs=8.7, color="#444444")
    label(ax, 6.12, 3.78, "actual\nbetween B1 and B2", fs=8.7, color=GREEN, weight="bold")
    label(ax, 10.42, 3.78, "future\ncontrol only", fs=8.7, color=MID_GRAY, weight="bold")

    # Down arrow to classification.
    arrow(ax, 6.0, 3.55, 6.0, 3.08, color="#333333", lw=1.1, ms=12)
    label(ax, 6.0, 2.88, "Each neighbor retrieval event is classified by accuracy and test-session relation", fs=10.2, weight="bold")

    # Rules.
    box(ax, 1.05, 2.08, 2.65, 0.58, "Accuracy\ncorrect = acc; otherwise = inc", fc="#ffffff", ec="#9ca3af", fs=8.6)
    box(ax, 4.68, 2.08, 2.65, 0.58, "Session relation\nsame as B2 = same", fc="#ffffff", ec="#9ca3af", fs=8.6)
    box(ax, 8.30, 2.08, 2.65, 0.58, "Otherwise\nacross-session", fc="#ffffff", ec="#9ca3af", fs=8.6)

    # Cell matrix.
    x0, y0 = 2.25, 0.30
    cw, ch = 1.8, 0.48
    label(ax, x0 + 2.25, 1.92, "Four actual predictor cells", fs=10.2, weight="bold")
    box(ax, x0 + cw, y0 + 2 * ch, cw, ch, "same", fc="#e5e7eb", ec=MID_GRAY, fs=9.1, weight="bold")
    box(ax, x0 + 2 * cw, y0 + 2 * ch, cw, ch, "across", fc="#e5e7eb", ec=MID_GRAY, fs=9.1, weight="bold")
    box(ax, x0, y0 + ch, cw, ch, "acc", fc="#e5e7eb", ec=MID_GRAY, fs=9.1, weight="bold")
    box(ax, x0, y0, cw, ch, "inc", fc="#e5e7eb", ec=MID_GRAY, fs=9.1, weight="bold")
    box(ax, x0 + cw, y0 + ch, cw, ch, "acc / same", fc=LIGHT_GREEN, ec=MID_GRAY, fs=9.4, weight="bold")
    box(ax, x0 + 2 * cw, y0 + ch, cw, ch, "acc / across", fc=LIGHT_RED, ec=MID_GRAY, fs=9.4, weight="bold")
    box(ax, x0 + cw, y0, cw, ch, "inc / same", fc=LIGHT_GREEN, ec=MID_GRAY, fs=9.4, weight="bold")
    box(ax, x0 + 2 * cw, y0, cw, ch, "inc / across", fc=LIGHT_RED, ec=MID_GRAY, fs=9.4, weight="bold")

    # Predictor summary.
    box(ax, 8.05, 0.60, 2.85, 0.82, "Predictor value per cell\nclosest: 1 / nearest d\nweighted: sum w(d)", fc="#fafafa", ec="#9ca3af", fs=8.7, weight="bold")

    fig.tight_layout()
    for ext in ("png", "svg"):
        fig.savefig(OUT_DIR / f"fig_method_simple_neighbor_schematic.{ext}", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    draw_schematic()
