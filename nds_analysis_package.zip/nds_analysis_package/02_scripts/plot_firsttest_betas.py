#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Plot the first-test beta figure used by the manuscript.

This script reads the output of `run_firsttest_lagonly_glmer_models.R` and
plots the two manuscript-facing measures: closest neighbor and exp_h32
weighted sum.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


CONDITIONS = [
    ("acc", "same", "Accurate / same-session"),
    ("acc", "across", "Accurate / across-session"),
    ("inc", "same", "Inaccurate / same-session"),
    ("inc", "across", "Inaccurate / across-session"),
]

COLORS = {
    ("acc", "same"): "#2f7d5b",
    ("acc", "across"): "#4c72b0",
    ("inc", "same"): "#c44e52",
    ("inc", "across"): "#dd9f22",
}


def sig_from_q(q: float) -> str:
    if pd.isna(q):
        return ""
    if q < 0.001:
        return "***"
    if q < 0.01:
        return "**"
    if q < 0.05:
        return "*"
    return "ns"


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--results",
        default=str(root / "03_results_glmer" / "firsttest_lagonly_glmer_manuscript_main_closeness_exp_h32.csv"),
    )
    parser.add_argument("--out-dir", default=str(root / "04_figures_glmer"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    data = pd.read_csv(args.results)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    measures = ["closeness", "exp_h32"]
    x = np.arange(len(measures))
    width = 0.18
    fig, ax = plt.subplots(figsize=(8.2, 4.35), dpi=300)

    for i, (family, relation, label) in enumerate(CONDITIONS):
        vals, errs, qs = [], [], []
        for measure in measures:
            row = data[
                (data["measure"] == measure)
                & (data["family"] == family)
                & (data["session_relation"] == relation)
            ].iloc[0]
            vals.append(float(row.beta_log_odds))
            errs.append(1.96 * float(row.se))
            q_col = "q_fdr_primary_28" if "q_fdr_primary_28" in row.index else "q_fdr_within_measure"
            qs.append(float(row[q_col]))
        pos = x + (i - 1.5) * width
        ax.bar(
            pos,
            vals,
            yerr=errs,
            width=width,
            capsize=2,
            label=label,
            color=COLORS[(family, relation)],
            edgecolor="#222222",
            linewidth=0.4,
        )
        for px, val, err, q in zip(pos, vals, errs, qs):
            star = sig_from_q(q)
            y = val + err + 0.025 if val >= 0 else val - err - 0.035
            va = "bottom" if val >= 0 else "top"
            ax.text(px, y, star, ha="center", va=va, fontsize=8)

    ax.axhline(0, color="#333333", linewidth=0.8)
    ax.set_xticks(x)
    ax.set_xticklabels(["Closest neighbor", "Weighted sum (exp h=32)"])
    ax.set_ylabel("Standardized log-odds coefficient")
    ax.set_title("First-Test effects under the lag-control model")
    ax.legend(frameon=False, ncol=2, fontsize=8)
    ax.grid(axis="y", alpha=0.18)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_ylim(-0.58, 0.82)
    fig.tight_layout()

    for ext in ["png", "svg"]:
        fig.savefig(out_dir / f"fig1_firsttest_closest_exp_h32_betas.{ext}", bbox_inches="tight")
    plt.close(fig)
    print(out_dir / "fig1_firsttest_closest_exp_h32_betas.png")


if __name__ == "__main__":
    main()
