#!/usr/bin/env Rscript

# Run the manuscript first-test lag-control models with participant as a
# random intercept using lme4::glmer(..., family = binomial).
#
# Model, fit separately for each neighborhood measure:
#
#   target_correct ~
#     z(actual_acc_same_measure)
#   + z(actual_acc_across_measure)
#   + z(actual_inc_same_measure)
#   + z(actual_inc_across_measure)
#   + log_lag
#   + (1 | subject)
#
# Outputs are written in a CSV schema compatible with the earlier Python
# first-test result tables, so existing figure/table scripts can read the main
# coefficient table after changing the input path.

suppressPackageStartupMessages({
  if (!requireNamespace("lme4", quietly = TRUE)) {
    stop("Package 'lme4' is required. Install it with install.packages('lme4').", call. = FALSE)
  }
})

conditions <- list(
  list(family = "acc", relation = "same", condition = "accurate_same"),
  list(family = "acc", relation = "across", condition = "accurate_across"),
  list(family = "inc", relation = "same", condition = "inaccurate_same"),
  list(family = "inc", relation = "across", condition = "inaccurate_across")
)

measures <- c(
  "closeness",
  "inverse_d",
  "inverse_sqrt_d",
  "exp_h2",
  "exp_h8",
  "exp_h32",
  "exp_h128"
)

parse_args <- function() {
  script_path <- tryCatch(normalizePath(sys.frames()[[1]]$ofile), error = function(e) NA_character_)
  if (is.na(script_path)) {
    args_all <- commandArgs(trailingOnly = FALSE)
    marker <- "--file="
    script_arg <- args_all[startsWith(args_all, marker)][1]
    script_path <- normalizePath(sub(marker, "", script_arg, fixed = TRUE))
  }
  root <- normalizePath(file.path(dirname(script_path), ".."))

  defaults <- list(
    main_table = file.path(root, "01_data", "analysis_ready", "table_main_trialOrder_eventAnchor_sameSession_md256.csv"),
    out_dir = file.path(root, "03_results_glmer"),
    optimizer = "bobyqa",
    maxfun = "200000",
    nAGQ = "1"
  )

  args <- commandArgs(trailingOnly = TRUE)
  i <- 1
  while (i <= length(args)) {
    key <- args[[i]]
    if (!startsWith(key, "--")) {
      stop(paste("Unexpected argument:", key), call. = FALSE)
    }
    if (i == length(args)) {
      stop(paste("Missing value for argument:", key), call. = FALSE)
    }
    value <- args[[i + 1]]
    name <- sub("^--", "", key)
    name <- gsub("-", "_", name)
    defaults[[name]] <- value
    i <- i + 2
  }
  defaults$maxfun <- as.integer(defaults$maxfun)
  defaults$nAGQ <- as.integer(defaults$nAGQ)
  defaults
}

zscore <- function(x) {
  x <- as.numeric(x)
  m <- mean(x)
  s <- sqrt(mean((x - m)^2))
  if (!is.finite(s) || s <= 0) {
    return(rep(0, length(x)))
  }
  (x - m) / s
}

population_sd <- function(x) {
  x <- as.numeric(x)
  m <- mean(x)
  sqrt(mean((x - m)^2))
}

sig_label <- function(p) {
  if (!is.finite(p)) return("ns")
  if (p < 0.001) return("***")
  if (p < 0.01) return("**")
  if (p < 0.05) return("*")
  if (p < 0.10) return("\u2020")
  "ns"
}

condition_rows <- function(measure) {
  rows <- lapply(conditions, function(cond) {
    raw_col <- paste("actual", cond$family, cond$relation, measure, sep = "_")
    z_col <- paste0("z_", raw_col)
    data.frame(
      family = cond$family,
      session_relation = cond$relation,
      condition = cond$condition,
      predictor = raw_col,
      z_predictor = z_col,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, rows)
}

fit_measure <- function(table, measure, optimizer, maxfun, nAGQ, out_dir) {
  df <- table
  conds <- condition_rows(measure)

  for (i in seq_len(nrow(conds))) {
    raw_col <- conds$predictor[[i]]
    z_col <- conds$z_predictor[[i]]
    df[[z_col]] <- zscore(df[[raw_col]])
  }

  df$target_correct <- as.integer(df$target_correct)
  df$subject <- as.factor(df$subject)
  fixed_terms <- c(conds$z_predictor, "log_lag")
  formula_text <- paste(
    "target_correct ~",
    paste(fixed_terms, collapse = " + "),
    "+ (1 | subject)"
  )
  model_formula <- stats::as.formula(formula_text)

  control <- lme4::glmerControl(
    optimizer = optimizer,
    optCtrl = list(maxfun = maxfun),
    calc.derivs = TRUE
  )

  model <- lme4::glmer(
    formula = model_formula,
    data = df,
    family = stats::binomial(link = "logit"),
    control = control,
    nAGQ = nAGQ
  )

  coef_mat <- coef(summary(model))
  fixed_term_names <- rownames(coef_mat)
  fixed_df <- data.frame(
    measure = measure,
    term = fixed_term_names,
    estimate = as.numeric(coef_mat[, "Estimate"]),
    se = as.numeric(coef_mat[, "Std. Error"]),
    z = as.numeric(coef_mat[, "z value"]),
    p = as.numeric(coef_mat[, "Pr(>|z|)"]),
    model_formula = formula_text,
    engine = "lme4::glmer",
    family_model = "binomial(logit)",
    optimizer = optimizer,
    nAGQ = nAGQ,
    stringsAsFactors = FALSE
  )

  vc <- as.matrix(stats::vcov(model))
  vc_out <- data.frame(term = rownames(vc), vc, check.names = FALSE)
  utils::write.csv(
    vc_out,
    file.path(out_dir, paste0("firsttest_lagonly_glmer_vcov_", measure, ".csv")),
    row.names = FALSE
  )

  random_df <- as.data.frame(lme4::VarCorr(model))
  random_subject_sd <- random_df$sdcor[
    random_df$grp == "subject" & random_df$var1 == "(Intercept)"
  ][1]

  opt <- model@optinfo
  conv_messages <- character()
  if (!is.null(opt$conv$lme4$messages)) {
    conv_messages <- c(conv_messages, as.character(opt$conv$lme4$messages))
  }
  if (!is.null(opt$conv$opt)) {
    if (is.list(opt$conv$opt) && !is.null(opt$conv$opt$message)) {
      conv_messages <- c(conv_messages, as.character(opt$conv$opt$message))
    } else if (length(opt$conv$opt) > 0) {
      conv_messages <- c(conv_messages, paste("optimizer convergence code:", paste(opt$conv$opt, collapse = ",")))
    }
  }
  convergence_message <- paste(unique(conv_messages), collapse = " | ")
  singular <- lme4::isSingular(model, tol = 1e-4)

  rows <- lapply(seq_len(nrow(conds)), function(i) {
    term <- conds$z_predictor[[i]]
    if (!term %in% rownames(coef_mat)) {
      stop(paste("Missing fixed term in model:", term), call. = FALSE)
    }
    est <- as.numeric(coef_mat[term, "Estimate"])
    se <- as.numeric(coef_mat[term, "Std. Error"])
    z <- as.numeric(coef_mat[term, "z value"])
    p <- as.numeric(coef_mat[term, "Pr(>|z|)"])
    raw_col <- conds$predictor[[i]]
    data.frame(
      measure = measure,
      family = conds$family[[i]],
      session_relation = conds$session_relation[[i]],
      condition = conds$condition[[i]],
      predictor = raw_col,
      beta_log_odds = est,
      se = se,
      z = z,
      p = p,
      raw_mean = mean(as.numeric(df[[raw_col]])),
      raw_sd = population_sd(df[[raw_col]]),
      n = nrow(df),
      n_subjects = length(unique(df$subject)),
      random_intercept_sd = random_subject_sd,
      model_formula = formula_text,
      engine = "lme4::glmer",
      family_model = "binomial(logit)",
      optimizer = optimizer,
      nAGQ = nAGQ,
      is_singular = singular,
      convergence_message = convergence_message,
      stringsAsFactors = FALSE
    )
  })

  result_df <- do.call(rbind, rows)
  result_df$q_fdr_within_measure <- stats::p.adjust(result_df$p, method = "BH")
  result_df$sig_raw <- vapply(result_df$p, sig_label, character(1))
  result_df$sig_fdr <- vapply(result_df$q_fdr_within_measure, sig_label, character(1))

  diagnostics <- data.frame(
    measure = measure,
    n = nrow(df),
    n_subjects = length(unique(df$subject)),
    random_intercept_sd = random_subject_sd,
    is_singular = singular,
    convergence_message = convergence_message,
    logLik = as.numeric(stats::logLik(model)),
    AIC = stats::AIC(model),
    BIC = stats::BIC(model),
    deviance = stats::deviance(model),
    optimizer = optimizer,
    nAGQ = nAGQ,
    stringsAsFactors = FALSE
  )

  list(results = result_df, fixed = fixed_df, diagnostics = diagnostics)
}

main <- function() {
  args <- parse_args()
  if (!file.exists(args$main_table)) {
    stop(paste("Cannot find main table:", args$main_table), call. = FALSE)
  }
  dir.create(args$out_dir, recursive = TRUE, showWarnings = FALSE)

  table <- utils::read.csv(args$main_table, stringsAsFactors = FALSE)
  all_results <- list()
  all_fixed <- list()
  all_diag <- list()

  for (measure in measures) {
    message("Fitting glmer model: ", measure)
    fit <- fit_measure(
      table = table,
      measure = measure,
      optimizer = args$optimizer,
      maxfun = args$maxfun,
      nAGQ = args$nAGQ,
      out_dir = args$out_dir
    )
    all_results[[measure]] <- fit$results
    all_fixed[[measure]] <- fit$fixed
    all_diag[[measure]] <- fit$diagnostics
  }

  results <- do.call(rbind, all_results)
  fixed <- do.call(rbind, all_fixed)
  diagnostics <- do.call(rbind, all_diag)
  results$q_fdr_primary_28 <- stats::p.adjust(results$p, method = "BH")
  results$sig_fdr_primary_28 <- vapply(results$q_fdr_primary_28, sig_label, character(1))

  utils::write.csv(
    results,
    file.path(args$out_dir, "firsttest_lagonly_glmer_all_measures.csv"),
    row.names = FALSE
  )
  utils::write.csv(
    fixed,
    file.path(args$out_dir, "firsttest_lagonly_glmer_fixed_terms.csv"),
    row.names = FALSE
  )
  utils::write.csv(
    diagnostics,
    file.path(args$out_dir, "firsttest_lagonly_glmer_diagnostics.csv"),
    row.names = FALSE
  )
  utils::write.csv(
    results[results$measure == "closeness", ],
    file.path(args$out_dir, "firsttest_lagonly_glmer_closest.csv"),
    row.names = FALSE
  )
  utils::write.csv(
    results[grepl("^(inverse|exp_)", results$measure), ],
    file.path(args$out_dir, "firsttest_lagonly_glmer_weighted_decay_all.csv"),
    row.names = FALSE
  )
  utils::write.csv(
    results[results$measure %in% c("closeness", "exp_h32"), ],
    file.path(args$out_dir, "firsttest_lagonly_glmer_manuscript_main_closeness_exp_h32.csv"),
    row.names = FALSE
  )

  message("Wrote glmer outputs to: ", args$out_dir)
}

main()
