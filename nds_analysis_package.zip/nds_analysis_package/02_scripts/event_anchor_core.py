#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Event-anchor same-session neighbour pipeline.

This module implements the current event-anchor definition. A neighbour is a presentation event A_m, not an image selected by its first encoding location. A_m is eligible if it is within +/- max_distance raw GLOBAL_ORDER trials of the target anchor and, in same-session mode, occurs in the same SESSION as that target anchor. Each neighbour anchor contributes through up to two subsequent retrieval events, A_(m+1) and A_(m+2), when available. These two follow-up retrieval events are pooled into the same predictor family: each event is classified independently, and no any-success aggregation is applied.

First-Test analyses use B1 as the target anchor and B2 as the target outcome. This manuscript companion version includes only first-test main-table construction.

Distances are always raw trial-order distances: abs(GLOBAL_ORDER(A_m) - GLOBAL_ORDER(target anchor)). encoding_rank and singleton-rank definitions are not used in this event-anchor implementation.
"""
from __future__ import annotations
import argparse
import glob
import math
import os
from typing import Dict, Iterable, List, Tuple
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests
CONDITIONS = [('acc', 'same'), ('acc', 'across'), ('inc', 'same'), ('inc', 'across')]
ALL_MEASURES = ['closeness', 'inverse_d', 'inverse_sqrt_d', 'exp_h2', 'exp_h8', 'exp_h32', 'exp_h128']
EVENT_DISTANCE_BASIS = 'trial_order'
EVENT_SESSION_MODES = ('all', 'same')

def _validate_event_settings(distance_basis: str, neighbor_event_session: str) -> None:
    if distance_basis != EVENT_DISTANCE_BASIS:
        raise ValueError("Event-anchor pipeline only supports distance_basis='trial_order'.")
    if neighbor_event_session not in EVENT_SESSION_MODES:
        raise ValueError(f'neighbor_event_session must be one of {EVENT_SESSION_MODES}; got {neighbor_event_session!r}.')

def event_anchor_tag(neighbor_event_session: str) -> str:
    """event_anchor_tag. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    _validate_event_settings(EVENT_DISTANCE_BASIS, neighbor_event_session)
    return 'trialOrder_eventAnchor_sameSession' if neighbor_event_session == 'same' else 'trialOrder_eventAnchor_allSession'

def weight_functions():
    """weight_functions. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    wf = {'inverse_d': lambda d: 1.0 / d, 'inverse_sqrt_d': lambda d: 1.0 / math.sqrt(d)}
    for h in [2, 8, 32, 128]:
        wf[f'exp_h{h}'] = lambda d, h=h: 2 ** (-(d - 1) / h)
    return wf

def correct_from_iscorrect(row):
    """correct_from_iscorrect. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    v = row.get('ISCORRECT', np.nan)
    return 0 if pd.isna(v) else int(v == 1)

def find_files(data_dir):
    """find_files. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    files = sorted(set(glob.glob(os.path.join(data_dir, 'sub*_responses.tsv')) + glob.glob(os.path.join(data_dir, 'responses_sub*.tsv'))))
    if not files:
        raise FileNotFoundError(f'No response TSVs in {data_dir}')
    return files

def load_subject_file(path):
    """load_subject_file. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    df = pd.read_csv(path, sep='\t').sort_values(['SESSION', 'RUN', 'TRIAL']).reset_index(drop=True)
    df['GLOBAL_ORDER'] = np.arange(len(df), dtype=int)
    return df

def zscore(s):
    """zscore. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    sd = s.std(ddof=0)
    return (s - s.mean()) / sd if sd > 0 else s * 0.0

def fit_logit(df, predictors):
    """fit_logit. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    formula = 'target_correct ~ ' + ' + '.join(predictors + ['log_lag', 'C(subject)'])
    return smf.glm(formula=formula, data=df, family=sm.families.Binomial()).fit(cov_type='HC3')

def contrast(res, wmap):
    """contrast. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    names = res.params.index.tolist()
    for nm, v in wmap.items():
        if abs(v) > 0 and nm not in names:
            return (np.nan, np.nan, np.nan, np.nan)
    w = np.zeros(len(names))
    for nm, v in wmap.items():
        if nm in names:
            w[names.index(nm)] = v
    est = float(np.dot(w, res.params))
    se = float(np.sqrt(np.dot(w, np.dot(res.cov_params(), w))))
    z = est / se if se > 0 else np.nan
    p = 2 * (1 - norm.cdf(abs(z))) if np.isfinite(z) else np.nan
    return (est, se, z, p)

def build_event_transitions(df: pd.DataFrame) -> pd.DataFrame:
    """Build candidate event anchors and their first two follow-up retrieval events.

    Target transitions still use the first or second subsequent appearance (e.g., B1 -> B2).
    Candidate anchors A_m retain that immediate transition in next_* fields and,
    when present, also carry followup2_* fields for A_(m+2).  The feature builders
    independently classify both follow-up events and pool their contributions.
    """
    if df.empty:
        return pd.DataFrame()
    subj = int(df['SUBJECT'].iloc[0])
    records: List[dict] = []
    for item, g in df.groupby('10KID'):
        g = g.sort_values('GLOBAL_ORDER').reset_index(drop=True)
        for pos in range(len(g) - 1):
            anchor = g.iloc[pos]
            nxt = g.iloc[pos + 1]
            if pos + 2 < len(g):
                nxt2 = g.iloc[pos + 2]
                followup2_order = int(nxt2['GLOBAL_ORDER'])
                followup2_session = int(nxt2['SESSION'])
                followup2_correct = correct_from_iscorrect(nxt2)
            else:
                followup2_order = -1
                followup2_session = -1
                followup2_correct = -1
            records.append({
                'subject': subj,
                'item_id': int(item),
                'anchor_occurrence': int(pos + 1),
                'next_occurrence': int(pos + 2),
                'anchor_order': int(anchor['GLOBAL_ORDER']),
                'anchor_session': int(anchor['SESSION']),
                'next_order': int(nxt['GLOBAL_ORDER']),
                'next_session': int(nxt['SESSION']),
                'next_correct': correct_from_iscorrect(nxt),
                'followup2_occurrence': int(pos + 3) if pos + 2 < len(g) else -1,
                'followup2_order': followup2_order,
                'followup2_session': followup2_session,
                'followup2_correct': followup2_correct,
                'first_order': int(g.iloc[0]['GLOBAL_ORDER']),
            })
    out = pd.DataFrame(records)
    if out.empty:
        return out
    return out.sort_values('anchor_order').reset_index(drop=True)

def _iter_candidate_followups(cand: pd.Series):
    """Yield A_(m+1) and, when present, A_(m+2) as separate retrieval events."""
    yield (int(cand['next_order']), int(cand['next_session']), int(cand['next_correct']), 1)
    if 'followup2_order' in cand and int(cand['followup2_order']) >= 0:
        yield (int(cand['followup2_order']), int(cand['followup2_session']), int(cand['followup2_correct']), 2)

def _init_feature_containers(include_direction: bool=False):
    """_init_feature_containers. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    wf = weight_functions()
    closest = {}
    wsum = {}
    directions = ['back', 'fwd'] if include_direction else [None]
    for dr in directions:
        for src in ['actual', 'future']:
            for family, relation in CONDITIONS:
                key = (dr, src, family, relation) if include_direction else (src, family, relation)
                closest[key] = None
                for wn in wf:
                    wkey = (dr, src, family, relation, wn) if include_direction else (src, family, relation, wn)
                    wsum[wkey] = 0.0
    return (wf, closest, wsum)

def _classify_followup(candidate_next_order: int, candidate_next_session: int, candidate_next_correct: int, target_anchor_order: int, target_outcome_order: int, target_outcome_session: int):
    """_classify_followup. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    if target_anchor_order < candidate_next_order < target_outcome_order:
        source = 'actual'
    elif candidate_next_order > target_outcome_order:
        source = 'future'
    else:
        return None
    family = 'acc' if int(candidate_next_correct) == 1 else 'inc'
    relation = 'same' if int(candidate_next_session) == int(target_outcome_session) else 'across'
    return (source, family, relation)

def _add_event_contribution(closest: dict, wsum: dict, wf: dict, d: int, source: str, family: str, relation: str, direction: str | None=None) -> None:
    """_add_event_contribution. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    if direction is None:
        ckey = (source, family, relation)
        if closest[ckey] is None or d < closest[ckey]:
            closest[ckey] = d
        for wn, fn in wf.items():
            wsum[source, family, relation, wn] += fn(d)
    else:
        ckey = (direction, source, family, relation)
        if closest[ckey] is None or d < closest[ckey]:
            closest[ckey] = d
        for wn, fn in wf.items():
            wsum[direction, source, family, relation, wn] += fn(d)

def _finalize_features(rec: dict, closest: dict, wsum: dict, wf: dict, prefix: str='', include_direction: bool=False) -> None:
    """_finalize_features. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    directions = ['back', 'fwd'] if include_direction else [None]
    for dr in directions:
        for src in ['actual', 'future']:
            for family, relation in CONDITIONS:
                if include_direction:
                    dm = closest[dr, src, family, relation]
                    base = f'{prefix}{dr}_{src}_{family}_{relation}'
                    rec[f'{base}_closeness'] = 0.0 if dm is None else 1.0 / dm
                    for wn in wf:
                        rec[f'{base}_{wn}'] = wsum[dr, src, family, relation, wn]
                else:
                    dm = closest[src, family, relation]
                    base = f'{prefix}{src}_{family}_{relation}'
                    rec[f'{base}_closeness'] = 0.0 if dm is None else 1.0 / dm
                    for wn in wf:
                        rec[f'{base}_{wn}'] = wsum[src, family, relation, wn]

def _candidate_slice(anchor_orders: np.ndarray, target_order: int, max_distance: int) -> Tuple[int, int]:
    """_candidate_slice. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    lo = int(np.searchsorted(anchor_orders, target_order - max_distance, side='left'))
    hi = int(np.searchsorted(anchor_orders, target_order + max_distance, side='right'))
    return (lo, hi)

def build_main_table(data_dir: str, max_distance: int, keep_singletons: bool=False, distance_basis: str='trial_order', neighbor_event_session: str='same') -> pd.DataFrame:
    """build_main_table. See docs/FEATURE_ENGINEERING_EVENT_ANCHOR.md for event-anchor definitions."""
    _validate_event_settings(distance_basis, neighbor_event_session)
    if keep_singletons:
        print('[note] --keep-singletons has no effect in event-anchor trial_order mode.')
    rows: List[dict] = []
    for path in find_files(data_dir):
        df = load_subject_file(path)
        events = build_event_transitions(df)
        if events.empty:
            continue
        anchors = events[events['anchor_occurrence'] == 1].copy()
        if anchors.empty:
            continue
        candidates = events.sort_values('anchor_order').reset_index(drop=True)
        orders = candidates['anchor_order'].to_numpy(dtype=int)
        subj = int(events['subject'].iloc[0])
        for _, target in anchors.iterrows():
            t_item = int(target['item_id'])
            t_anchor = int(target['anchor_order'])
            t_outcome = int(target['next_order'])
            t_anchor_session = int(target['anchor_session'])
            t_outcome_session = int(target['next_session'])
            rec = {'subject': subj, 'item_id': t_item, 'target_anchor_occurrence': int(target['anchor_occurrence']), 'target_anchor_order': t_anchor, 'target_outcome_order': t_outcome, 'target_correct': int(target['next_correct']), 'log_lag': math.log(max(1, t_outcome - t_anchor))}
            wf, closest, wsum = _init_feature_containers(include_direction=False)
            lo, hi = _candidate_slice(orders, t_anchor, max_distance)
            for j in range(lo, hi):
                cand = candidates.iloc[j]
                if int(cand['item_id']) == t_item:
                    continue
                if neighbor_event_session == 'same' and int(cand['anchor_session']) != t_anchor_session:
                    continue
                d = abs(int(cand['anchor_order']) - t_anchor)
                if d < 1 or d > max_distance:
                    continue
                for followup_order, followup_session, followup_correct, _h in _iter_candidate_followups(cand):
                    label = _classify_followup(followup_order, followup_session, followup_correct, t_anchor, t_outcome, t_outcome_session)
                    if label is None:
                        continue
                    source, family, relation = label
                    _add_event_contribution(closest, wsum, wf, d, source, family, relation)
            _finalize_features(rec, closest, wsum, wf, include_direction=False)
            rows.append(rec)
    return pd.DataFrame(rows)

# This manuscript companion core intentionally stops after build_main_table.
# Directional, third-appearance, second-test, future-control, and interaction
# analysis functions are not included in this package.
