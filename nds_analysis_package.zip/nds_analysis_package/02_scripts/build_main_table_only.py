#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build only the first-test event-anchor table used by the manuscript.

This wrapper intentionally does not build directional, second-test, or
third-appearance tables. It calls the validated Followup12 event-anchor core
definition and writes the current manuscript-facing first-test table.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from event_anchor_core import build_main_table, event_anchor_tag


def parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=str(root / "01_data" / "raw_data"))
    parser.add_argument("--out-dir", default=str(root / "01_data" / "analysis_ready"))
    parser.add_argument("--max-distance", type=int, default=256)
    parser.add_argument("--neighbor-event-session", choices=["same", "all"], default="same")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    table = build_main_table(
        data_dir=args.data_dir,
        max_distance=args.max_distance,
        keep_singletons=False,
        distance_basis="trial_order",
        neighbor_event_session=args.neighbor_event_session,
    )
    tag = event_anchor_tag(args.neighbor_event_session)
    out_path = out_dir / f"table_main_{tag}_md{args.max_distance}.csv"
    table.to_csv(out_path, index=False)
    print(f"Wrote {out_path} shape={table.shape}")


if __name__ == "__main__":
    main()
