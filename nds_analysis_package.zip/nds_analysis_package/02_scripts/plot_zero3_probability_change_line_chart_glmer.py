#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Plot zero-reference probability-change curves from lme4::glmer outputs.

This script is the glmer counterpart of
`plot_zero3_probability_change_line_chart.py`. It does not refit the model.
Instead, it reads:

- the analysis-ready table, to recover predictor means/SDs and log_lag mean;
- `firsttest_lagonly_glmer_fixed_terms.csv`, for fixed-effect estimates;
- `firsttest_lagonly_glmer_vcov_<measure>.csv`, for fixed-effect covariance.

Predictions are population-level fixed-effect predictions with the participant
random intercept set to zero. Confidence bands are Wald/delta-method bands
based on the fixed-effect covariance matrix.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
TABLE_PATH = ROOT / "01_data" / "analysis_ready" / "table_main_trialOrder_eventAnchor_sameSession_md256.csv"
GLMER_DIR = ROOT / "03_results_glmer"
OUT_DIR = ROOT / "04_figures_glmer"
OUT_DIR.mkdir(parents=True, exist_ok=True)

CONDITIONS = [
    ("acc", "same", "Accurate / same-session", "#2f7d5b"),
    ("acc", "across", "Accurate / across-session", "#4c72b0"),
    ("inc", "same", "Inaccurate / same-session", "#c44e52"),
    ("inc", "across", "Inaccurate / across-session", "#e0a11b"),
]


def logistic(x: float | np.ndarray) -> float | np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def z_info(df: pd.DataFrame, measure: str) -> dict[tuple[str, str], dict]:
    out = {}
    for fam, rel, _label, _color in CONDITIONS:
        raw_col = f"actual_{fam}_{rel}_{measure}"
        values = df[raw_col].astype(float)
        mean = float(values.mean())
        sd = float(values.std(ddof=0))
        if not np.isfinite(sd) or sd <= 0:
            raise ValueError(f"Invalid SD for {raw_col}: {sd}")
        out[(fam, rel)] = {
            "raw_col": raw_col,
            "std_name": f"z_{raw_col}",
            "mean": mean,
            "sd": sd,
            "z_min_observed": float((values.min() - mean) / sd),
            "z_max_observed": float((values.max() - mean) / sd),
        }
    return out


def load_glmer_fixed(measure: str, glmer_dir: Path) -> tuple[list[str], np.ndarray, np.ndarray]:
    fixed = pd.read_csv(glmer_dir / "firsttest_lagonly_glmer_fixed_terms.csv")
    fixed = fixed[fixed["measure"].eq(measure)].copy()
    if fixed.empty:
        raise FileNotFoundError(f"No glmer fixed terms for measure={measure}")

    vc = pd.read_csv(glmer_dir / f"firsttest_lagonly_glmer_vcov_{measure}.csv")
    terms = vc["term"].tolist()
    cov = vc.drop(columns=["term"]).to_numpy(float)

    beta_map = dict(zip(fixed["term"], fixed["estimate"]))
    missing = [term for term in terms if term not in beta_map]
    if missing:
        raise ValueError(f"Fixed-term CSV missing covariance terms: {missing}")
    beta = np.array([float(beta_map[term]) for term in terms], dtype=float)
    return terms, beta, cov


def base_row(df: pd.DataFrame, terms: list[str]) -> np.ndarray:
    row = np.zeros(len(terms), dtype=float)
    if "(Intercept)" in terms:
        row[terms.index("(Intercept)")] = 1.0
    row[terms.index("log_lag")] = float(df["log_lag"].mean())
    return row


def prediction_change(beta: np.ndarray, cov: np.ndarray, focal_row: np.ndarray, ref_row: np.ndarray):
    eta = float(focal_row @ beta)
    eta_ref = float(ref_row @ beta)
    p = float(logistic(eta))
    p_ref = float(logistic(eta_ref))
    diff = p - p_ref
    grad = p * (1.0 - p) * focal_row - p_ref * (1.0 - p_ref) * ref_row
    se = float(np.sqrt(max(grad @ cov @ grad, 0.0)))
    return diff, diff - 1.96 * se, diff + 1.96 * se, p, p_ref, se


def build_closest_effects(df: pd.DataFrame, glmer_dir: Path, closest_scale: str) -> pd.DataFrame:
    measure = "closeness"
    terms, beta, cov = load_glmer_fixed(measure, glmer_dir)
    info = z_info(df, measure)
    base = base_row(df, terms)
    distances = np.geomspace(1.0, 256.0, 240) if closest_scale == "log" else np.linspace(1.0, 256.0, 256)

    rows = []
    for fam, rel, label, color in CONDITIONS:
        zi = info[(fam, rel)]
        col_idx = terms.index(zi["std_name"])
        ref_row = base.copy()
        ref_z = (0.0 - zi["mean"]) / zi["sd"]
        ref_row[col_idx] = ref_z
        for distance in distances:
            raw_value = 1.0 / float(distance)
            z_value = (raw_value - zi["mean"]) / zi["sd"]
            focal_row = base.copy()
            focal_row[col_idx] = z_value
            diff, lo, hi, pred, pred_ref, se = prediction_change(beta, cov, focal_row, ref_row)
            rows.append(
                {
                    "panel": "closest",
                    "measure": measure,
                    "family": fam,
                    "session_relation": rel,
                    "condition": label,
                    "color": color,
                    "x": float(distance),
                    "raw_predictor": raw_value,
                    "z_predictor": z_value,
                    "reference": "focal_no_neighbor_raw_0",
                    "reference_z": ref_z,
                    "probability_change": diff,
                    "ci_low": lo,
                    "ci_high": hi,
                    "predicted_probability": pred,
                    "reference_probability": pred_ref,
                    "se": se,
                }
            )
    return pd.DataFrame(rows)


def build_weighted_effects(df: pd.DataFrame, measure: str, glmer_dir: Path) -> pd.DataFrame:
    terms, beta, cov = load_glmer_fixed(measure, glmer_dir)
    info = z_info(df, measure)
    base = base_row(df, terms)

    rows = []
    for fam, rel, label, color in CONDITIONS:
        zi = info[(fam, rel)]
        col_idx = terms.index(zi["std_name"])
        ref_row = base.copy()
        ref_z = (0.0 - zi["mean"]) / zi["sd"]
        ref_row[col_idx] = ref_z

        x_grid = np.linspace(0.0, 3.0, 240)
        z_grid = ref_z + x_grid
        for x_value, z_value in zip(x_grid, z_grid):
            raw_value = zi["mean"] + z_value * zi["sd"]
            focal_row = base.copy()
            focal_row[col_idx] = float(z_value)
            diff, lo, hi, pred, pred_ref, se = prediction_change(beta, cov, focal_row, ref_row)
            rows.append(
                {
                    "panel": "weighted",
                    "measure": measure,
                    "family": fam,
                    "session_relation": rel,
                    "condition": label,
                    "color": color,
                    "x": float(x_value),
                    "raw_predictor": raw_value,
                    "z_predictor": float(z_value),
                    "reference": "focal_no_neighbor_raw_0",
                    "reference_z": ref_z,
                    "probability_change": diff,
                    "ci_low": lo,
                    "ci_high": hi,
                    "predicted_probability": pred,
                    "reference_probability": pred_ref,
                    "se": se,
                    "observed_support": bool(raw_value >= -1e-12),
                    "z_min_observed": zi["z_min_observed"],
                    "z_max_observed": zi["z_max_observed"],
                }
            )
    return pd.DataFrame(rows)


def setup_style():
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 9.5,
            "axes.titlesize": 11.5,
            "axes.labelsize": 10.2,
            "legend.fontsize": 8.3,
            "xtick.labelsize": 9.0,
            "ytick.labelsize": 9.0,
        }
    )


def plot_effects(effects: pd.DataFrame, weighted_measure: str, closest_scale: str, output_stem: str):
    setup_style()
    fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.45), dpi=300, sharey=True)
    specs = [
        ("closest", "Closest-neighbor effect", "Distance to nearest qualifying neighbor"),
        ("weighted", f"Weighted-sum effect ({weighted_measure.replace('exp_h', 'exp h=')})", "Weighted-history strength above no-neighbor (SD units)"),
    ]

    for ax, (panel, title, xlabel) in zip(axes, specs):
        sub_panel = effects[effects["panel"].eq(panel)]
        for fam, rel, label, color in CONDITIONS:
            sub = sub_panel[
                sub_panel["family"].eq(fam) & sub_panel["session_relation"].eq(rel)
            ].sort_values("x")
            ax.plot(sub["x"], sub["probability_change"], color=color, lw=2.0, label=label)
            ax.fill_between(sub["x"].to_numpy(float), sub["ci_low"].to_numpy(float), sub["ci_high"].to_numpy(float), color=color, alpha=0.16, linewidth=0)
        ax.axhline(0, color="#333333", lw=0.9, ls="--", alpha=0.8)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.grid(axis="y", color="#eeeeee", lw=0.8)
        ax.spines[["top", "right"]].set_visible(False)
        if panel == "closest" and closest_scale == "log":
            ax.set_xscale("log", base=2)
            ax.set_xticks([1, 2, 4, 8, 16, 32, 64, 128, 256])
            ax.get_xaxis().set_major_formatter(plt.ScalarFormatter())
        if panel == "weighted":
            ax.set_xlim(0, 3)
            ax.set_xticks([0, 1, 2, 3])

    axes[0].set_ylabel("Predicted probability change from no-neighbor reference")
    reference_handle = plt.Line2D([0], [0], color="#333333", lw=0.9, ls="--", alpha=0.8)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        [reference_handle] + handles,
        ["Reference"] + labels,
        loc="lower center",
        ncol=5,
        frameon=False,
        bbox_to_anchor=(0.5, -0.012),
    )
    fig.tight_layout(rect=[0, 0.075, 1, 1])
    for ext in ["png", "svg"]:
        fig.savefig(OUT_DIR / f"{output_stem}.{ext}", bbox_inches="tight")
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--table", default=str(TABLE_PATH))
    parser.add_argument("--glmer-dir", default=str(GLMER_DIR))
    parser.add_argument("--weighted-measure", default="exp_h32")
    parser.add_argument("--closest-scale", choices=["log", "linear"], default="log")
    parser.add_argument("--output-stem", default="fig2_zero3_probability_change_h32_glmer")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    df = pd.read_csv(args.table)
    glmer_dir = Path(args.glmer_dir)
    closest = build_closest_effects(df, glmer_dir, args.closest_scale)
    weighted = build_weighted_effects(df, args.weighted_measure, glmer_dir)
    effects = pd.concat([closest, weighted], ignore_index=True)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    effects.to_csv(OUT_DIR / f"{args.output_stem}.csv", index=False)
    plot_effects(effects, args.weighted_measure, args.closest_scale, args.output_stem)
    print(OUT_DIR / f"{args.output_stem}.png")


if __name__ == "__main__":
    main()
